package Model;

public class Historico {
    
}
